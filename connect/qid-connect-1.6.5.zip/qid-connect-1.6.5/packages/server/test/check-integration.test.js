// Regression tests for skills/qid-connect/scripts/check-integration.mjs.
//
// Why this file exists: the checker was rewritten in 1.6.0, 1.6.1 and 1.6.2, and
// every serious finding in those audits was in it. It was also the only code
// here without tests, so each round of fixes was verified by hand and the
// verification thrown away. Every scenario below is one that was found broken by
// an audit or fixed in response to one. They are cheap to run and they mean the
// next change to that script is checked by `bun test` instead of by someone
// noticing.
//
// The servers use node:http so this needs no dependencies beyond the SDK.

import { test, expect } from "bun:test";
import { createServer } from "node:http";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { createQidConnect } from "../src/core.js";
import { qidMiddleware } from "../src/middleware.js";

const here = dirname(fileURLToPath(import.meta.url));
const CHECKER = join(here, "../../../skills/qid-connect/scripts/check-integration.mjs");
const SECRET = "s".repeat(40);

// Start a server on an ephemeral port. `shape` can rewrite the response before
// the qID routes see it, which is how the proxy/WAF cases are simulated.
async function serve({ mount = "/qid", apiPath, originFor, shape, root } = {}) {
  const server = createServer((req, res) => {
    if (shape && shape(req, res)) return;
    const path = (req.url || "/").split("?")[0];
    if (path === "/" && root) return root(req, res);
    if (path.startsWith(mount)) return handler(req, res);
    res.statusCode = 404;
    res.end("not found");
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const origin = `http://127.0.0.1:${server.address().port}`;
  const qid = createQidConnect({
    origin: originFor ? originFor(origin) : origin,
    sessionSecret: SECRET,
    ...(apiPath ? { apiPath } : {}),
  });
  const handler = qidMiddleware(qid, { basePath: mount });
  return { origin, close: () => new Promise((r) => server.close(r)) };
}

async function runChecker(...args) {
  const proc = Bun.spawn(["bun", CHECKER, ...args], { stdout: "pipe", stderr: "pipe" });
  const [stdout, stderr] = await Promise.all([
    new Response(proc.stdout).text(),
    new Response(proc.stderr).text(),
  ]);
  const exitCode = await proc.exited;
  return { out: stdout + stderr, exitCode };
}


// Assert on the named check, not on the presence of the word FAIL anywhere: a
// test that accepts "something failed" passes when the wrong thing fails, which
// is how the first version of the WAF test below silently lost its teeth.
function failedCheck(out, name) {
  return new RegExp(`^FAIL\\s+${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`, "m").test(out);
}
function passedCheck(out, name) {
  return new RegExp(`^PASS\\s+${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`, "m").test(out);
}

// --- the happy path -------------------------------------------------------

test("a correct integration passes every check and exits 0", async () => {
  const s = await serve();
  try {
    const { out, exitCode } = await runChecker(s.origin);
    expect(out).toContain("The surface is wired correctly");
    expect(out).not.toContain("FAIL");
    expect(exitCode).toBe(0);
  } finally {
    await s.close();
  }
}, 30_000);

// --- argument handling (1.6.2: --api= was silently dropped) ---------------

test("--api=<path> is honoured, not silently ignored", async () => {
  const s = await serve({ mount: "/api/qid", apiPath: "/api/qid" });
  try {
    const spaced = await runChecker(s.origin, "--api", "/api/qid");
    const equals = await runChecker(s.origin, "--api=/api/qid");
    // The whole bug was that these two disagreed on a correct integration.
    expect(equals.exitCode).toBe(spaced.exitCode);
    expect(equals.exitCode).toBe(0);
    expect(equals.out).toContain("routes at /api/qid");
  } finally {
    await s.close();
  }
}, 30_000);

test("an unknown flag is fatal rather than ignored", async () => {
  const { out, exitCode } = await runChecker("http://127.0.0.1:1", "--api-path", "/qid");
  expect(out).toContain("Unknown option");
  expect(exitCode).toBe(2);
}, 15_000);

test("a bare host:port is rejected with a usable suggestion", async () => {
  const { out, exitCode } = await runChecker("localhost:8788");
  expect(out).toContain("Did you mean http://localhost:8788");
  expect(exitCode).toBe(2);
}, 15_000);

test("an unreachable site exits 2 (could not run), not 1 (a check failed)", async () => {
  const { exitCode } = await runChecker("http://127.0.0.1:1");
  expect(exitCode).toBe(2);
}, 15_000);

// --- the checks that must not pass a broken deployment --------------------

test("a WAF answering 403 on /verify cannot score a clean run", async () => {
  // 1.6.1 reported "10/10 the surface is wired correctly" here, while browser
  // sign-in was impossible: the check accepted any 403, not the SDK's own.
  const s = await serve({
    shape: (req, res) => {
      if (req.method === "POST" && req.url.startsWith("/qid/verify")) {
        res.statusCode = 403;
        res.setHeader("content-type", "text/html");
        res.end("<html>Blocked</html>");
        return true;
      }
      return false;
    },
  });
  try {
    const { out, exitCode } = await runChecker(s.origin);
    // The point of the check is that the SDK itself answered, so a 403 from
    // something else must fail THIS check, not merely fail the run.
    expect(failedCheck(out, "POST /verify rejects a cross-site Origin")).toBe(true);
    expect(out).not.toContain("The surface is wired correctly");
    expect(exitCode).toBe(1);
  } finally {
    await s.close();
  }
}, 30_000);

test("a wrong origin is caught and named", async () => {
  const s = await serve({ originFor: () => "https://www.example.com" });
  try {
    const { out, exitCode } = await runChecker(s.origin);
    expect(failedCheck(out, "challenge rp_origin matches the site origin")).toBe(true);
    expect(exitCode).toBe(1);
  } finally {
    await s.close();
  }
}, 30_000);

test("routes mounted elsewhere without apiPath fail proof_url, not the mount", async () => {
  // The Next.js shape: desktop paste keeps working, phones 404, so this is the
  // failure that reaches production unnoticed.
  const s = await serve({ mount: "/api/qid" });
  try {
    const { out } = await runChecker(s.origin, "--api", "/api/qid");
    expect(failedCheck(out, "request.proof_url points at your own /proof route")).toBe(true);
    // and the mount itself must be reported as fine, or the hint blames the wrong thing
    expect(passedCheck(out, "POST /challenge issues a well-formed challenge")).toBe(true);
  } finally {
    await s.close();
  }
}, 30_000);

// --- the checks that must not fail a working deployment -------------------

test("a root that redirects to an unrelated host is not called an origin bug", async () => {
  // 1.6.1 failed this correct integration and printed a hint that, if followed,
  // breaks every browser sign-in.
  const s = await serve({
    root: (_req, res) => {
      res.statusCode = 302;
      res.setHeader("location", "https://login.identity.example/authorize");
      res.end();
    },
  });
  try {
    const { out, exitCode } = await runChecker(s.origin);
    expect(passedCheck(out, "site does not canonicalize to a different origin")).toBe(true);
    expect(out).toContain("not an origin problem");
    expect(exitCode).toBe(0);
  } finally {
    await s.close();
  }
}, 30_000);

// --- CSP: the claim the site makes about this script ----------------------

const hostedWidgetPage = `<script type="module">import { mountQidConnect } from "https://qid.dev/connect/widget.js";</script>`;

test("a CSP that blocks the hosted widget is reported", async () => {
  const s = await serve({
    root: (_req, res) => {
      res.setHeader("content-security-policy", "default-src 'self'; script-src 'self'");
      res.setHeader("content-type", "text/html");
      res.end(hostedWidgetPage);
    },
  });
  try {
    const { out, exitCode } = await runChecker(s.origin);
    expect(failedCheck(out, "CSP allows the hosted widget")).toBe(true);
    expect(exitCode).toBe(1);
  } finally {
    await s.close();
  }
}, 30_000);

test("a CSP that allows qid.dev does not false-fail", async () => {
  // The exact pattern the docs prescribe for hosted-widget sites, and what
  // dashboard/build/btc2btx serve in production. It must score clean.
  const s = await serve({
    root: (_req, res) => {
      res.setHeader(
        "content-security-policy",
        "default-src 'self'; script-src 'self' https://qid.dev; style-src 'self' 'unsafe-inline'"
      );
      res.setHeader("content-type", "text/html");
      res.end(hostedWidgetPage);
    },
  });
  try {
    const { out, exitCode } = await runChecker(s.origin);
    expect(out).not.toContain("FAIL");
    expect(exitCode).toBe(0);
  } finally {
    await s.close();
  }
}, 30_000);

// --- CSP: the widget's runtime-injected styles -----------------------------
//
// The incident these exist for: a live site shipped style-src 'self' with a
// hash of index.html's own style. Every check passed, and the sign-in dialog
// rendered as raw unstyled HTML, because the widget injects its stylesheet at
// runtime and nothing looked at style-src.

test("a style-src without 'unsafe-inline' blocks the widget's styles and is reported", async () => {
  // The literal incident shape: script-src fixed, style-src hash-pinned.
  const s = await serve({
    root: (_req, res) => {
      res.setHeader(
        "content-security-policy",
        "default-src 'self'; script-src 'self' https://qid.dev; " +
          "style-src 'self' 'sha256-0Ynkc6aJPBLoK5KkEZFwvXFHF1p6cQCTNqkFAT0Ldh0='"
      );
      res.setHeader("content-type", "text/html");
      res.end(hostedWidgetPage);
    },
  });
  try {
    const { out, exitCode } = await runChecker(s.origin);
    expect(failedCheck(out, "CSP allows the widget's runtime styles")).toBe(true);
    // and the script side must still pass, or the hint points at the wrong directive
    expect(passedCheck(out, "CSP allows the hosted widget")).toBe(true);
    expect(exitCode).toBe(1);
  } finally {
    await s.close();
  }
}, 30_000);

test("a hash next to 'unsafe-inline' still fails: browsers ignore 'unsafe-inline'", async () => {
  // CSP2+ semantics: any nonce or hash source in the directive disables
  // 'unsafe-inline', so this policy blocks the widget despite naming it.
  const s = await serve({
    root: (_req, res) => {
      res.setHeader(
        "content-security-policy",
        "script-src 'self' https://qid.dev; " +
          "style-src 'self' 'unsafe-inline' 'sha256-0Ynkc6aJPBLoK5KkEZFwvXFHF1p6cQCTNqkFAT0Ldh0='"
      );
      res.setHeader("content-type", "text/html");
      res.end(hostedWidgetPage);
    },
  });
  try {
    const { out, exitCode } = await runChecker(s.origin);
    expect(failedCheck(out, "CSP allows the widget's runtime styles")).toBe(true);
    expect(exitCode).toBe(1);
  } finally {
    await s.close();
  }
}, 30_000);

test("default-src governs styles when style-src is absent", async () => {
  // No style-src at all does not mean unrestricted: default-src 'self' still
  // blocks the injected <style> element.
  const s = await serve({
    root: (_req, res) => {
      res.setHeader("content-security-policy", "default-src 'self'; script-src 'self' https://qid.dev");
      res.setHeader("content-type", "text/html");
      res.end(hostedWidgetPage);
    },
  });
  try {
    const { out, exitCode } = await runChecker(s.origin);
    expect(failedCheck(out, "CSP allows the widget's runtime styles")).toBe(true);
    expect(exitCode).toBe(1);
  } finally {
    await s.close();
  }
}, 30_000);

test("a CSP with no style directive leaves styles unrestricted and does not false-fail", async () => {
  const s = await serve({
    root: (_req, res) => {
      res.setHeader("content-security-policy", "script-src 'self' https://qid.dev");
      res.setHeader("content-type", "text/html");
      res.end(hostedWidgetPage);
    },
  });
  try {
    const { out, exitCode } = await runChecker(s.origin);
    expect(passedCheck(out, "CSP allows the widget's runtime styles")).toBe(true);
    expect(out).not.toContain("FAIL");
    expect(exitCode).toBe(0);
  } finally {
    await s.close();
  }
}, 30_000);

test("a page that does not use the hosted widget is not judged on CSP", async () => {
  const s = await serve({
    root: (_req, res) => {
      res.setHeader("content-security-policy", "default-src 'self'; script-src 'self'");
      res.setHeader("content-type", "text/html");
      res.end("<div id=signin></div>");
    },
  });
  try {
    const { out, exitCode } = await runChecker(s.origin);
    expect(out).not.toContain("FAIL");
    expect(exitCode).toBe(0);
  } finally {
    await s.close();
  }
}, 30_000);

// --- evidence lines must not overstate ------------------------------------

test("the store check never claims round trips it did not complete", async () => {
  // 1.6.1 printed "4/4 round trips kept the nonce" after making zero.
  let n = 0;
  const s = await serve({
    shape: (req, res) => {
      if (req.method === "POST" && req.url.startsWith("/qid/challenge") && ++n > 1) {
        res.statusCode = 429;
        res.setHeader("content-type", "application/json");
        res.end(JSON.stringify({ ok: false }));
        return true;
      }
      return false;
    },
  });
  try {
    const { out } = await runChecker(s.origin);
    expect(out).not.toContain("4/4 round trips kept the nonce");
  } finally {
    await s.close();
  }
}, 30_000);
