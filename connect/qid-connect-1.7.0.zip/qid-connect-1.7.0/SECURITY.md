# qID Connect security

## Reporting a vulnerability

If you believe you have found a security vulnerability in qID Connect,
**please report it privately** — do not open a public issue.

- **Preferred:** GitHub → Security → *Report a vulnerability* (private
  security advisory) on this repository.
- **Email:** SheikhMende@gmail.com — put `[qID Connect security]` in the
  subject. You may request a secure channel before sending details.
- **Response targets:** acknowledgment within **72 hours**; triage verdict
  within **7 days**; coordinated disclosure within **90 days** of report
  (sooner for actively exploited issues). Session-forgery,
  proof-replay/origin-binding bypass, and verifier issues are treated as
  highest severity.

**Scope.** The server SDK (challenge issuance, nonce single-use and retire
semantics, proof verification, the vendored frozen v1 verifier, session
cookies and the login-CSRF guards on `/verify` and `/poll`, the QR
rendezvous poll-secret flow, the SQLite stores), the widget (request
handling, rotation, transports including the `btxqid://` deep link
encoding), and the reference test signer. Out of scope: cosmetic issues in
the demo pages, and denial-of-service against the in-memory demo stores
(documented as such; production deployments supply durable stores).

**A note on impact bounds:** a qID sign-in proof is domain-separated from
transactions and can never move funds. The maximum impact of a full
compromise of a qID Connect deployment is stolen sessions on that one
site — never coins. Reports demonstrating anything beyond that bound
(e.g. a login-domain artifact accepted anywhere in a spend path) are
highest severity and very welcome.

**Supported versions:** the latest release line only.

**Recognition:** good-faith researchers are credited in release notes
(opt-out available).
