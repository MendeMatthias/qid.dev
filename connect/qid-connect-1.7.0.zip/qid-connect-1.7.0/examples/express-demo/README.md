# qID Connect express demo

A complete site where register and login are wallet-only. No email field, no
password, no signup form. The first successful sign-in creates the account
from the verified address.

## Run it

```
bun install        # once, from the repo root
bun server.js
open http://localhost:8788
```

## Sign in with the real wallet

PQ Wallet for BTX v0.21 or later. Click "Sign in with qID", copy the request,
open the wallet, Settings, qID Sign-In, paste, sign, copy the proof, paste it
back.

## Sign in without a wallet (test signer)

Click the button, take `nonce` and `ts` from the request shown in step 1, and
run from the repo root:

```
bun tools/signer/btx-sign-ownership.mjs --random \
  --origin http://localhost:8788 --nonce <nonce> --ts <ts>
```

Paste the printed proof JSON into step 2. `--random` makes a throwaway wallet,
so every run is a new account.

## What to look at

- `server.js`: the whole backend. The login system is one middleware line.
  Accounts persist to `accounts.json` with the address as the key and an
  optional display name as the only profile field.
- `public/index.html`: the whole frontend. Mounts the widget, shows the
  member area when a session exists.
