// app/api/qid/[action]/route.js
//
// The whole qID Connect backend for a Next.js app. Serves six routes:
//   POST /api/qid/challenge   POST /api/qid/verify   POST /api/qid/proof
//   GET  /api/qid/poll        GET  /api/qid/session   POST /api/qid/logout
// (proof + poll are the cross-device QR / deep-link pair.)
//
// The default stores are in-memory. For production, pass a shared nonceStore
// and a database-backed accounts adapter to createQidConnect (see
// packages/server/src/stores.js for both interfaces).

import { createQidConnect } from "@qid/connect-server";
import { qidNextHandlers } from "@qid/connect-server/next";

const qid = createQidConnect({
  origin: process.env.QID_ORIGIN,
  sessionSecret: process.env.QID_SESSION_SECRET,
  // REQUIRED on Next: the routes live under /api/qid, so the proof URL baked
  // into the QR and deep link must point there too. Omit this and the phone's
  // proof POSTs to /qid/proof and 404s — QR and deep-link sign-in silently fail
  // (only copy-paste works). Must match where you mount the widget: api:"/api/qid".
  apiPath: "/api/qid",
});

export const { GET, POST } = qidNextHandlers(qid);
