# qID Connect browser demo (for qid.dev)

A live "Sign in with qID" that anyone can try with no wallet and no backend.
It runs the real product code: the real widget, the real frozen v1 verifier,
and the real reference signer, all bundled to run in the browser. The tab
plays all three roles (site server, wallet, and the signed-in browser), so a
visitor experiences the exact flow and ends up signed in as a real generated
BTX address. Nothing about the verification is faked; only the transport and
the session live in memory in the page instead of on a server.

## Files

- `index.html` the demo page and the in-browser stand-in for the server.
- `playground.src.js` the bundle entry (real widget + verifier + signer).
- `playground.bundle.js` the built bundle. Rebuild after changing any of the
  product code:

```
bun build examples/browser-demo/playground.src.js \
  --outfile examples/browser-demo/playground.bundle.js \
  --format esm --target browser --minify
```

## Host it

Static files. Drop the folder anywhere, or embed the page on qid.dev at a
path like /demo. No server logic is required; the demo is deliberately
self-contained so it doubles as proof you can save and open offline.

## Honest framing

The page says plainly that everything runs in the browser for the demo, and
that in a real app the challenge and verification happen on the site's
server while the user signs in their own wallet. The point is to let someone
feel the flow in ten seconds, then read INTEGRATION.md to build the real one.
