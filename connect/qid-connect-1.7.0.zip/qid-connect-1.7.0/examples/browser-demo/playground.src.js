// playground.src.js
//
// Bundle entry for the qid.dev browser demo. Pulls together the REAL product
// code, so what a visitor tries is exactly what ships:
//   - the real Sign in with qID widget
//   - the real frozen v1 verifier
//   - the real reference signer (plays a wallet, in the browser)
//
// bun build examples/browser-demo/playground.src.js \
//   --outfile examples/browser-demo/playground.bundle.js \
//   --format esm --target browser --minify
//
// The page script (in index.html) uses window.qidDemo to run an in-browser
// stand-in for the site's server, so the whole flow completes with no wallet
// and no backend. Honest label on the page: everything runs in your browser.
//
// SPDX-License-Identifier: MIT

import { mountQidConnect, mountQidAccount } from "../../packages/widget/src/qid-connect-widget.js";
import {
  makeChallenge,
  verifyOwnership,
  verifySignIn,
} from "../../packages/server/src/verifier/btx-ownership-verify.js";
import { buildProof } from "../../tools/signer/btx-sign-ownership.mjs";

window.qidDemo = { mountQidConnect, mountQidAccount, makeChallenge, verifyOwnership, verifySignIn, buildProof };
