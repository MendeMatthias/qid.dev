# Names and mark

The code in this repository is MIT licensed. The MIT license covers the
code, not the identity of the project.

"qID", "qID Connect", "Sign in with qID", and the qID mark (the geometric q
with the electron dot) identify the official project and the official
protocol implementations. They are not licensed for use by forks or
derivative works.

What this means in practice:

- You may use, modify, and ship this code under the MIT terms, including
  commercially.
- A fork or derivative must use its own name and its own mark, and must not
  present itself as qID, qID Connect, or an official or endorsed version of
  either.
- Unmodified integrations are encouraged to use the "Sign in with qID"
  button as specified in `docs/DESIGN.md`; that is what the button is for.
- Wallets may describe themselves as qID compatible only if they follow the
  qID signer rules; compatibility claims that break those rules are
  misrepresentation.

Questions or requests about naming and compatibility: through qid.dev.
