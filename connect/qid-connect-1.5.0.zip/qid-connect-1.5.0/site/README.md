# qID Connect preview sites

Pages in the qid.dev family look. Deploy the plain sources to qid.dev; the
gated builds are only for the private-preview window.

- `intro/index.html` an epic Commodore/Atari-style ASCII boot screen: a typed
  loader, a CRT scanline effect, the ANSI-shadow qID Connect banner, then the
  links. Repo swag and a fun front door. Self-contained, no assets needed.
- `connect/index.html` the qID Connect landing page. Uses `__HERO__` as a
  placeholder that the build inlines from `assets/qid-connect-hero.png`.
- `integrate/index.html` the integrator guide, deployed at
  qid.dev/connect/integrate — THE link to hand a BTX dApp developer. How it
  works, get the code, Express/Next wiring, the button, testing without a
  wallet, endpoints, security properties. Self-contained, no assets needed.
  Mirrored to the qid.dev repo (and qid-main/site) on deploy.
- `challenge/index.html` the Challenge page, the seven claims to attack,
  built from `docs/AUDIT-BRIEF.md`.

## Open Graph

`connect`, `challenge`, and the browser demo carry OG and Twitter meta with
1200x630 cards in `assets/og/` (`og-connect.png`, `og-challenge.png`). The
meta URLs are absolute placeholders under `https://qid.dev/`; point them at
your host and serve the OG images at `/og/` on deploy.

## Password-gated builds

`build-gate.mjs` wraps a page in a real password gate: the content is
encrypted with AES-256-GCM under a key derived from the password via
PBKDF2-SHA256 (200k iterations), and the output is ciphertext plus a small
decryptor. Without the password the file reveals nothing. This is not a
hidden div.

```
export QID_GATE_PASSWORD="the-shared-password"
bun site/build-gate.mjs site/connect/index.html    site/dist/connect.html --hero assets/qid-connect-hero.png
bun site/build-gate.mjs site/challenge/index.html  site/dist/challenge.html
```

Outputs land in `site/dist/` (gitignored). Share the single HTML file plus
the password out of band. The password lives only in the environment, never
in the repo.

## Going public later

The gate is only for the preview window. To publish a page for real, deploy
the plain source from `connect/` or `challenge/` (with the hero inlined or
served alongside), not the gated build. Removing the gate is the whole
"make it public" step.

## Verified

Both gates were driven in a browser: wrong password is rejected, the correct
password decrypts and renders the full page, and the gated files contain no
plaintext of the content.
