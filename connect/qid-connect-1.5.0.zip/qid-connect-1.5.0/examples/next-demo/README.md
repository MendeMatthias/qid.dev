# Next.js drop-in

The same wallet-only login for a Next.js App Router project. Three files, no
other changes. The runnable reference app is `../express-demo`; this folder
holds the exact files you drop into a Next project.

## 1. Install the SDK

Copy `packages/server` into your project (or install the package once it is
published) and install its three dependencies:

```
npm i @noble/post-quantum @noble/hashes @scure/base
```

## 2. Copy the widget

Copy `packages/widget/src/qid-connect-widget.js` into your `public/` folder,
and `packages/widget/src/vendor/qrcode.mjs` into `public/vendor/`. The second
file is the vendored QR encoder the widget imports for the scan-with-phone
tab.

## 3. Drop in the three files

- `app/api/qid/[action]/route.js` serves the four login endpoints.
- `components/SignInWithQid.jsx` is the button.
- `app/page.jsx` shows the whole flow on a page.

Set two environment variables:

```
QID_ORIGIN=https://yourapp.com        # your exact web origin
QID_SESSION_SECRET=<32+ random chars> # rotate to sign everyone out
```

That is the entire integration. No email field, no password table, no user id
except the BTX address.
