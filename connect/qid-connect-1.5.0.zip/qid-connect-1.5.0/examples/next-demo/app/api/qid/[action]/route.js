// app/api/qid/[action]/route.js
//
// The whole qID Connect backend for a Next.js app. Serves:
//   POST /api/qid/challenge
//   POST /api/qid/verify
//   GET  /api/qid/session
//   POST /api/qid/logout
//
// The default stores are in-memory. For production, pass a shared nonceStore
// and a database-backed accounts adapter to createQidConnect (see
// packages/server/src/stores.js for both interfaces).

import { createQidConnect } from "@qid/connect-server";
import { qidNextHandlers } from "@qid/connect-server/next";

const qid = createQidConnect({
  origin: process.env.QID_ORIGIN,
  sessionSecret: process.env.QID_SESSION_SECRET,
});

export const { GET, POST } = qidNextHandlers(qid);
