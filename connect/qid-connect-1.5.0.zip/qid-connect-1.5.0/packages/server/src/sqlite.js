// sqlite.js
//
// Durable stores on SQLite. This is the production adapter for single-host
// deployments: nonces, poll secrets, and accounts survive restarts and are
// shared across processes through the database file.
//
// Driver-agnostic: pass any synchronous SQLite handle with exec() and
// prepare() returning statements with run() / get(). All three mainstream
// drivers share that exact shape:
//
//   import { Database } from "bun:sqlite";            // bun
//   import { DatabaseSync } from "node:sqlite";       // node 22+
//   import Database from "better-sqlite3";            // node, any version
//
//   const db = new Database("qid.sqlite");            // or new DatabaseSync(...)
//   const qid = createQidConnect({
//     origin, sessionSecret,
//     nonceStore: new SqliteNonceStore(db),
//     accounts: new SqliteAccounts(db),
//   });
//
// For multi-instance deployments use Redis or a SQL server implementing the
// same interfaces (documented in stores.js); this file doubles as the
// reference for how the operations must behave. The conformance tests in
// test/stores.test.js run against any adapter; point them at yours.
//
// SPDX-License-Identifier: MIT

export class SqliteNonceStore {
  constructor(db, { ttlMs = 10 * 60 * 1000, table = "qid_nonces" } = {}) {
    this.ttlMs = ttlMs;
    this.db = db;
    db.exec(
      `CREATE TABLE IF NOT EXISTS ${table} (
        nonce TEXT PRIMARY KEY,
        at INTEGER NOT NULL,
        used INTEGER NOT NULL DEFAULT 0,
        secret TEXT,
        address TEXT
      )`
    );
    this._insert = db.prepare(
      `INSERT OR REPLACE INTO ${table} (nonce, at, used, secret, address) VALUES (?, ?, 0, ?, NULL)`
    );
    this._get = db.prepare(`SELECT at, used, secret, address FROM ${table} WHERE nonce = ?`);
    this._consume = db.prepare(
      `UPDATE ${table} SET used = 1 WHERE nonce = ? AND used = 0 AND at >= ?`
    );
    this._complete = db.prepare(`UPDATE ${table} SET address = ? WHERE nonce = ? AND at >= ?`);
    this._delete = db.prepare(`DELETE FROM ${table} WHERE nonce = ?`);
    this._sweep = db.prepare(`DELETE FROM ${table} WHERE at < ?`);
  }
  issue(nonce, secret, now = Date.now()) {
    this._sweep.run(now - this.ttlMs);
    this._insert.run(nonce, now, secret || null);
  }
  has(nonce, now = Date.now()) {
    const rec = this._get.get(nonce);
    return !!rec && !rec.used && now - rec.at <= this.ttlMs;
  }
  consume(nonce, now = Date.now()) {
    // atomic: only one caller can flip used 0 -> 1
    const res = this._consume.run(nonce, now - this.ttlMs);
    return res.changes === 1;
  }
  complete(nonce, address, now = Date.now()) {
    return this._complete.run(address, nonce, now - this.ttlMs).changes === 1;
  }
  claim(nonce, secret, now = Date.now()) {
    const rec = this._get.get(nonce);
    if (
      !rec ||
      now - rec.at > this.ttlMs ||
      !rec.secret ||
      !timingSafeEqualStr(rec.secret, secret)
    ) {
      return { status: "expired" };
    }
    if (rec.address) {
      this._delete.run(nonce); // single use
      return { status: "done", address: rec.address };
    }
    return { status: "pending" };
  }
}

export class SqliteAccounts {
  constructor(db, { table = "qid_accounts" } = {}) {
    this.db = db;
    db.exec(
      `CREATE TABLE IF NOT EXISTS ${table} (
        address TEXT PRIMARY KEY,
        created_at INTEGER NOT NULL,
        profile TEXT NOT NULL DEFAULT '{}'
      )`
    );
    this._insert = db.prepare(
      `INSERT OR IGNORE INTO ${table} (address, created_at) VALUES (?, ?)`
    );
    this._get = db.prepare(`SELECT address, created_at, profile FROM ${table} WHERE address = ?`);
    this._patch = db.prepare(`UPDATE ${table} SET profile = ? WHERE address = ?`);
  }
  _row(rec) {
    if (!rec) return null;
    let profile = {};
    try {
      profile = JSON.parse(rec.profile);
    } catch {
      /* corrupt profile never blocks login */
    }
    return { address: rec.address, createdAt: rec.created_at, ...profile };
  }
  async getOrCreate(address, now = Date.now()) {
    this._insert.run(address, now);
    return this._row(this._get.get(address));
  }
  async get(address) {
    return this._row(this._get.get(address));
  }
  // Optional profile fields (display name, avatar) as a JSON patch. Email is
  // not a profile field; do not put one here.
  async patch(address, fields) {
    const rec = this._get.get(address);
    if (!rec) return null;
    let profile = {};
    try {
      profile = JSON.parse(rec.profile);
    } catch {
      /* start clean */
    }
    Object.assign(profile, fields);
    for (const k of Object.keys(profile)) {
      if (profile[k] == null) delete profile[k];
    }
    this._patch.run(JSON.stringify(profile), address);
    return this._row(this._get.get(address));
  }
}

function timingSafeEqualStr(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
