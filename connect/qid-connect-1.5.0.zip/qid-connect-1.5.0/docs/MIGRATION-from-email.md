# Migrating off email accounts

For integrators who wired up qID sign-in next to an existing email login.
That setup defeats the point: the user still has a password to phish and you
still hold an email database. Here is how to unbolt it.

## Target state

- `address` is the primary key of your accounts table.
- Sign in with qID is the only way in.
- Email, if it exists at all, is an optional contact field on the profile,
  never an identifier and never a credential.
- There is no password column and no password reset flow.

## Steps

1. Add the address column now. `ALTER TABLE users ADD COLUMN address TEXT
   UNIQUE`. New qID sign-ins that match no user create a fresh account with
   only the address set.

2. Link existing accounts one time. When a logged-in email user clicks
   "Connect wallet", run the normal qID flow and write the verified address
   onto their row. This is the only moment the two worlds touch. Refuse to
   link an address that already belongs to another account.

3. Flip the login. Make "Sign in with qID" the only button. An unlinked email
   user who signs in with their wallet gets a fresh wallet account; if they
   want their old data, they log in once more through a temporary
   "recover by email" link that finishes by linking the address and retiring
   the email login.

4. Retire the credentials. Drop the password column, delete the reset-flow
   code, and demote email to nullable contact data. Keep it only if your app
   actually sends mail, and say so in your privacy copy.

5. Enforce it going forward. New accounts get no email prompt at any point in
   sign-up, because there is no sign-up. First sign-in is registration.

## What you gain

- Nothing to phish: no password exists.
- Nothing to leak: your user table is a list of public addresses.
- Post-quantum login for free: the proof is an ML-DSA-44 signature, and it
  cannot move funds by construction.

## What about users without a wallet

The BTX PQ Wallet is a free download and creating an address takes seconds.
Your "Sign in" screen can link to it. That onboarding cost is the same one
every WalletConnect app accepts, and it buys you a user base where every
account is a wallet, which is the entire reason a BTX dApp exists.
